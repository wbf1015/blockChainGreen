### 使用了flask构建web界面的区块链

加入了flask做一个web站点

```
python python blockchain.py
```

现在访问：

http://localhost:8080

你在浏览器里就可以看到区块链的json结果了。
