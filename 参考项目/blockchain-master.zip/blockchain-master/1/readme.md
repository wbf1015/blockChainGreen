### 增加了index、时间戳的区块链

```
python blockchain.py
```

如果一切正常，你应该能得到类似如下的返回：

```json
[{"index": 0, "timestamp": 1533643792970, "data": "Genesis Block", "previous_hash": 0, "hash": "20785bf00afe3e19d675f9f82178171c36fdf0a88073fafd4e8f1d701993a9d4"}, {"index": 1, "timestamp": 1533643792970, "data": "hello", "previous_hash": "20785bf00afe3e19d675f9f82178171c36fdf0a88073fafd4e8f1d701993a9d4", "hash": "6609572ab73f3c67fe597936b481f23748573950141780348b28f1df36cf9b54"}, {"index": 2, "timestamp": 1533643792970, "data": "hi~", "previous_hash": "6609572ab73f3c67fe597936b481f23748573950141780348b28f1df36cf9b54", "hash": "71ce5960426c3aeec202f49bb767324425429aa7709fb0b68f489259dd9e9bc6"}, {"index": 3, "timestamp": 1533643792970, "data": "~", "previous_hash": "71ce5960426c3aeec202f49bb767324425429aa7709fb0b68f489259dd9e9bc6", "hash": "138a440071c51c4d6efa370ab7a42d6469d5252bb5a383913b89c8ea2c43b045"}]

```
