## 可以让信息上链的区块链

```
python python blockchain.py
```

现在，你可以把hello上链：

http://localhost:8080/say/hello

改变hello为hi，hi也上链了：

http://localhost:8080/say/hi
